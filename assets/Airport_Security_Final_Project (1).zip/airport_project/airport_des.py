"""
Airport Security Checkpoint Discrete-Event Simulation
BUAD 667 Final Project

Business question: Which checkpoint staffing/layout configuration reduces passenger wait,
bottlenecks, and missed-flight risk during a 4-hour morning peak?

Note: This script implements the same DES logic that would normally be implemented in SimPy:
entities arrive, request resources, wait in FIFO queues, receive service, and move to the next station.
It avoids external dependencies so it can run in any Python environment.
"""

import random
import statistics
import math
import heapq
import pandas as pd
import matplotlib.pyplot as plt

SIM_TIME = 240
N_REPLICATIONS = 30
BASE_SEED = 42
ARRIVAL_MEAN = 0.50
PRECHECK_PROB = 0.25
URGENT_PROB = 0.20
REG_ID_MEAN = 0.75
REG_SCAN_MEAN = 1.20
PRE_ID_MEAN = 0.35
PRE_SCAN_MEAN = 0.70


def mean_ci(values):
    mean = statistics.fmean(values)
    if len(values) < 2:
        return mean, mean, mean
    sd = statistics.stdev(values)
    half = 1.96 * sd / math.sqrt(len(values))
    return mean, mean - half, mean + half


def process_station(arrivals, service_times, capacity):
    """FIFO multi-server station. Returns start times, departures, waits, utilization."""
    servers = [0.0] * capacity
    heapq.heapify(servers)
    starts, departures, waits = [], [], []
    busy = 0.0
    for arrival, service in zip(arrivals, service_times):
        available = heapq.heappop(servers)
        start = max(arrival, available)
        depart = start + service
        wait = start - arrival
        heapq.heappush(servers, depart)
        starts.append(start)
        departures.append(depart)
        waits.append(wait)
        busy += service
    util = 100 * busy / (SIM_TIME * capacity)
    return starts, departures, waits, util


def generate_passengers(seed, arrival_mean, precheck_prob, urgent_prob):
    rng = random.Random(seed)
    t = 0.0
    rows = []
    pid = 0
    while True:
        t += rng.expovariate(1.0 / arrival_mean)
        if t > SIM_TIME:
            break
        pid += 1
        is_pre = rng.random() < precheck_prob
        is_urgent = rng.random() < urgent_prob
        rows.append({"pid": pid, "arrival": t, "precheck": is_pre, "urgent": is_urgent})
    return rows


def run_replication(seed, config):
    rng_service = random.Random(seed + 10000)
    passengers = generate_passengers(
        seed,
        config.get("arrival_mean", ARRIVAL_MEAN),
        config.get("precheck_prob", PRECHECK_PROB),
        config.get("urgent_prob", URGENT_PROB),
    )

    # service times are generated in passenger order so each replication is reproducible
    for p in passengers:
        if p["precheck"]:
            p["id_service"] = rng_service.expovariate(1.0 / PRE_ID_MEAN)
            p["scan_service"] = rng_service.expovariate(1.0 / PRE_SCAN_MEAN)
        else:
            p["id_service"] = rng_service.expovariate(1.0 / REG_ID_MEAN)
            p["scan_service"] = rng_service.expovariate(1.0 / REG_SCAN_MEAN)

    id_busy_total = 0.0
    scan_busy_total = 0.0
    total_id_cap = 0
    total_scan_cap = 0

    if config.get("shared", False):
        arrivals = [p["arrival"] for p in passengers]
        id_services = [p["id_service"] for p in passengers]
        _, id_departures, id_waits, id_util = process_station(arrivals, id_services, config["id_shared"])
        scan_services = [p["scan_service"] for p in passengers]
        _, scan_departures, scan_waits, scan_util = process_station(id_departures, scan_services, config["scan_shared"])
        for idx, p in enumerate(passengers):
            p["id_wait"] = id_waits[idx]
            p["scan_wait"] = scan_waits[idx]
            p["departure"] = scan_departures[idx]
        id_busy_total = id_util * SIM_TIME * config["id_shared"] / 100
        scan_busy_total = scan_util * SIM_TIME * config["scan_shared"] / 100
        total_id_cap = config["id_shared"]
        total_scan_cap = config["scan_shared"]
    else:
        # process regular and PreCheck streams separately at each station
        for is_pre, id_cap, scan_cap in [
            (False, config["id_reg"], config["scan_reg"]),
            (True, config["id_pre"], config["scan_pre"]),
        ]:
            group = [p for p in passengers if p["precheck"] == is_pre]
            arrivals = [p["arrival"] for p in group]
            id_services = [p["id_service"] for p in group]
            _, id_departures, id_waits, id_util = process_station(arrivals, id_services, id_cap)
            scan_services = [p["scan_service"] for p in group]
            _, scan_departures, scan_waits, scan_util = process_station(id_departures, scan_services, scan_cap)
            for idx, p in enumerate(group):
                p["id_wait"] = id_waits[idx]
                p["scan_wait"] = scan_waits[idx]
                p["departure"] = scan_departures[idx]
            id_busy_total += id_util * SIM_TIME * id_cap / 100
            scan_busy_total += scan_util * SIM_TIME * scan_cap / 100
            total_id_cap += id_cap
            total_scan_cap += scan_cap

    waits = [p["id_wait"] + p["scan_wait"] for p in passengers]
    reg_waits = [p["id_wait"] + p["scan_wait"] for p in passengers if not p["precheck"]]
    pre_waits = [p["id_wait"] + p["scan_wait"] for p in passengers if p["precheck"]]
    system_times = [p["departure"] - p["arrival"] for p in passengers]
    missed = [p for p in passengers if p["urgent"] and ((p["id_wait"] + p["scan_wait"] > 15) or (p["departure"] - p["arrival"] > 25))]
    served = len(passengers)

    waits_sorted = sorted(waits)
    return {
        "served": served,
        "avg_wait_all": statistics.fmean(waits) if waits else 0,
        "avg_wait_regular": statistics.fmean(reg_waits) if reg_waits else 0,
        "avg_wait_precheck": statistics.fmean(pre_waits) if pre_waits else 0,
        "p90_wait_all": waits_sorted[int(0.9 * (len(waits_sorted)-1))] if waits_sorted else 0,
        "max_wait_all": max(waits) if waits else 0,
        "avg_system_time": statistics.fmean(system_times) if system_times else 0,
        "missed_risk_pct": 100 * len(missed) / served if served else 0,
        "id_utilization": 100 * id_busy_total / (SIM_TIME * total_id_cap),
        "scan_utilization": 100 * scan_busy_total / (SIM_TIME * total_scan_cap),
    }


def run_config(name, config):
    rows = []
    for i in range(N_REPLICATIONS):
        rows.append(run_replication(BASE_SEED + i, config))
    df = pd.DataFrame(rows)
    df["config"] = name
    return df


configs = {
    "Baseline: dedicated Regular + PreCheck": {"id_reg": 3, "scan_reg": 3, "id_pre": 1, "scan_pre": 1},
    "Add scanner capacity": {"id_reg": 3, "scan_reg": 4, "id_pre": 1, "scan_pre": 1},
    "Add ID-check officer": {"id_reg": 4, "scan_reg": 3, "id_pre": 1, "scan_pre": 1},
    "Shared pooled lanes": {"shared": True, "id_shared": 4, "scan_shared": 4},
    "Peak surge baseline": {"id_reg": 3, "scan_reg": 3, "id_pre": 1, "scan_pre": 1, "arrival_mean": 0.40},
}

all_results = []
summary_rows = []
for name, cfg in configs.items():
    df = run_config(name, cfg)
    all_results.append(df)
    row = {"Configuration": name}
    for metric in ["served", "avg_wait_all", "avg_wait_regular", "avg_wait_precheck", "p90_wait_all", "max_wait_all", "avg_system_time", "missed_risk_pct", "id_utilization", "scan_utilization"]:
        mean, lo, hi = mean_ci(df[metric].tolist())
        row[f"{metric}_mean"] = mean
        row[f"{metric}_ci_low"] = lo
        row[f"{metric}_ci_high"] = hi
    summary_rows.append(row)

summary = pd.DataFrame(summary_rows)
summary.to_csv("airport_des_summary.csv", index=False)
pd.concat(all_results).to_csv("airport_des_replications.csv", index=False)

print("AIRPORT SECURITY DES SUMMARY")
print("=" * 100)
print(summary[[
    "Configuration", "served_mean", "avg_wait_all_mean", "avg_wait_regular_mean", "avg_wait_precheck_mean",
    "p90_wait_all_mean", "max_wait_all_mean", "missed_risk_pct_mean", "id_utilization_mean", "scan_utilization_mean"
]].to_string(index=False))

plot_df = summary.copy()
plt.figure(figsize=(10, 5))
plt.bar(plot_df["Configuration"], plot_df["avg_wait_all_mean"])
plt.xticks(rotation=25, ha="right")
plt.ylabel("Average wait (minutes)")
plt.title("DES Experiment: Average Wait by Airport Security Configuration")
plt.tight_layout()
plt.savefig("airport_des_avg_wait.png", dpi=200)

plt.figure(figsize=(10, 5))
plt.bar(plot_df["Configuration"], plot_df["missed_risk_pct_mean"])
plt.xticks(rotation=25, ha="right")
plt.ylabel("Missed-flight risk proxy (%)")
plt.title("DES Experiment: Urgent Passenger Delay Risk")
plt.tight_layout()
plt.savefig("airport_des_delay_risk.png", dpi=200)

plt.figure(figsize=(8, 5))
plt.scatter(plot_df["id_utilization_mean"], plot_df["scan_utilization_mean"])
for _, row in plot_df.iterrows():
    plt.annotate(row["Configuration"].split(":")[0], (row["id_utilization_mean"], row["scan_utilization_mean"]), fontsize=8)
plt.xlabel("ID-check utilization (%)")
plt.ylabel("Scanner utilization (%)")
plt.title("Bottleneck Diagnostic: ID vs Scanner Utilization")
plt.tight_layout()
plt.savefig("airport_des_utilization.png", dpi=200)
