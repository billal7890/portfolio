from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pptx import Presentation
from pptx.util import Inches as PInches, Pt as PPt
from pptx.dml.color import RGBColor as PRGBColor
import pandas as pd
from pathlib import Path

base = Path('/mnt/data/airport_project')
mc = pd.read_csv(base/'airport_mc_scenarios.csv')
des = pd.read_csv(base/'airport_des_summary.csv')

# ---------- DOCX ----------
doc = Document()
styles = doc.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(10.5)
styles['Heading 1'].font.name = 'Aptos Display'
styles['Heading 1'].font.size = Pt(18)
styles['Heading 2'].font.name = 'Aptos Display'
styles['Heading 2'].font.size = Pt(14)

sec = doc.sections[0]
sec.top_margin = Inches(0.6)
sec.bottom_margin = Inches(0.6)
sec.left_margin = Inches(0.7)
sec.right_margin = Inches(0.7)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Airport Security & Passenger Flow Optimization')
r.bold = True
r.font.size = Pt(20)
r.font.color.rgb = RGBColor(31,78,121)
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('BUAD 667: Simulation with AI for Business Applications\nFinal Group Project').italic = True
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('Structured simulation analysis: baseline assessment, sensitivity testing, scenario comparison, and operational recommendation.')

doc.add_heading('Executive Summary', level=1)
doc.add_paragraph(
    'This project analyzes an airport security checkpoint during a four-hour morning peak period using three simulation lenses: Monte Carlo simulation, agent-based modeling, and discrete-event simulation. The system is realistic because passenger demand is uncertain, passengers make individual lane choices, and the checkpoint contains queues and constrained resources.'
)
doc.add_paragraph(
    'The main recommendation is to add regular scanner capacity and improve passenger routing before adding more PreCheck capacity. In the Monte Carlo model, baseline operations show a 43.4% probability of a demand-capacity shortfall. Adding one regular lane reduces expected shortfall from 25.9 passengers to 3.1 passengers. In the DES model, adding scanner capacity reduces average wait from 0.56 to 0.25 minutes, while adding an ID-check officer has much smaller impact. This suggests that the scanner stage is the more important bottleneck under the baseline assumptions.'
)

doc.add_heading('1. System Description and Fit with Three Methods', level=1)
doc.add_paragraph(
    'The selected system is an airport security checkpoint with regular passengers and PreCheck passengers. Passengers arrive randomly, enter an ID-check queue, proceed to a scanner queue, and exit security. Some passengers are urgent because their flight departure time is closer. The airport manager wants to know whether to add scanners, add ID-check officers, pool lanes, or improve lane routing.'
)
doc.add_paragraph(
    'This system fits the group project requirement because each methodology answers a different question about the same system. The Monte Carlo model quantifies uncertainty in peak demand and capacity risk. The ABM model explains how individual passenger lane choices can create emergent congestion. The DES model tests queue performance, bottlenecks, utilization, and staffing configurations.'
)

# Table of model lenses
doc.add_heading('2. Model Questions', level=1)
table = doc.add_table(rows=1, cols=4)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = 'Table Grid'
hdr = table.rows[0].cells
for i, text in enumerate(['Method', 'Business Question', 'Key Outputs', 'Why This Method Fits']):
    hdr[i].text = text
rows = [
    ['Monte Carlo', 'How uncertain is peak checkpoint demand and how often is capacity insufficient?', 'Probability of shortfall, expected shortfall, risk cost, confidence interval, tornado diagram', 'Best for uncertainty and risk distribution.'],
    ['ABM', 'How do passenger lane-choice behaviors affect congestion?', 'Queue clustering, lane switching, processed passengers by lane, emergent imbalance', 'Best for individual decisions and emergent behavior.'],
    ['DES', 'Which staffing/layout configuration reduces wait time and bottlenecks?', 'Average wait, p90 wait, max wait, utilization, missed-flight risk proxy', 'Best for queues, resources, and process flow.'],
]
for row in rows:
    cells = table.add_row().cells
    for i, text in enumerate(row):
        cells[i].text = text


doc.add_heading('3. Monte Carlo Model', level=1)
doc.add_heading('3.1 Design', level=2)
doc.add_paragraph(
    'The Monte Carlo model defines uncertain inputs, runs 10,000 iterations with seed 42, computes summary statistics and a confidence interval, runs one-at-a-time sensitivity analysis, and compares operating scenarios. The output is an operational risk cost rather than profit.'
)
doc.add_paragraph(
    'Uncertain inputs include total passenger arrival rate, PreCheck share, regular lane processing capacity, and PreCheck lane processing capacity. Passenger arrivals are generated with a Poisson draw after sampling the hourly arrival rate. PreCheck passengers are generated with a Binomial draw from total passengers and sampled PreCheck share.'
)
doc.add_heading('3.2 Key Inputs', level=2)
table = doc.add_table(rows=1, cols=3)
table.style = 'Table Grid'
for i, text in enumerate(['Input', 'Distribution / Value', 'Justification']): table.rows[0].cells[i].text = text
for row in [
    ['Arrival rate', 'Triangular(90, 120, 160) passengers/hour', 'Expert estimate with low, likely, and high peak-demand values.'],
    ['PreCheck share', 'Triangular(15%, 25%, 35%)', 'Passenger mix is uncertain but bounded.'],
    ['Regular lane capacity', 'Normal(32, 5) passengers/hour/lane', 'Represents service variation and human process variability.'],
    ['PreCheck lane capacity', 'Normal(62, 6) passengers/hour/lane', 'PreCheck screening is faster but still variable.'],
    ['Risk cost', 'Staffing cost + $35 per shortfall passenger', 'Converts operational risk into a comparable decision metric.'],
]:
    cells=table.add_row().cells
    for i,text in enumerate(row): cells[i].text=text

doc.add_heading('3.3 Results', level=2)
base_mc = mc[mc['Scenario']=='Baseline'].iloc[0]
doc.add_paragraph(
    f"Baseline demand averages {base_mc['Mean passengers']:.1f} passengers during the four-hour peak. Expected shortfall is {base_mc['Mean shortfall']:.1f} passengers, and the probability of any shortfall is {base_mc['P(shortfall)']*100:.1f}%. The mean risk cost is ${base_mc['Mean risk cost']:,.0f}, with a 95% confidence interval from ${base_mc['CI lower']:,.0f} to ${base_mc['CI upper']:,.0f}."
)
doc.add_picture(str(base/'airport_mc_histogram.png'), width=Inches(5.7))
doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
p=doc.add_paragraph('Figure 1. Baseline Monte Carlo risk-cost distribution.')
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].italic=True

doc.add_picture(str(base/'airport_mc_tornado.png'), width=Inches(5.7))
doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
p=doc.add_paragraph('Figure 2. Tornado diagram showing drivers of operational risk.')
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].italic=True

doc.add_heading('3.4 Scenario Comparison', level=2)
table = doc.add_table(rows=1, cols=5)
table.style='Table Grid'
for i,text in enumerate(['Scenario','Mean shortfall','P(shortfall)','Mean risk cost','95th pct cost']): table.rows[0].cells[i].text=text
for _,row in mc.iterrows():
    cells=table.add_row().cells
    vals=[row['Scenario'], f"{row['Mean shortfall']:.1f}", f"{row['P(shortfall)']*100:.1f}%", f"${row['Mean risk cost']:,.0f}", f"${row['95th pct cost']:,.0f}"]
    for i,v in enumerate(vals): cells[i].text=str(v)

doc.add_paragraph(
    'The scenario comparison shows that a peak surge is the most dangerous condition, increasing probability of shortfall to 81.7%. Adding a regular lane reduces probability of shortfall to 7.3%, while adding PreCheck capacity does not materially address the main regular-lane shortage.'
)

# DES

doc.add_heading('4. Discrete-Event Simulation Model', level=1)
doc.add_heading('4.1 Design', level=2)
doc.add_paragraph(
    'The DES model represents passengers as entities flowing through two sequential stations: ID check and scanner. Each station has limited resources and FIFO queues. The model runs 30 replications of a 240-minute peak period using seeds 42 through 71. Metrics are reported as replication means with confidence intervals.'
)
doc.add_paragraph(
    'The model compares five configurations: baseline dedicated Regular and PreCheck lanes, adding scanner capacity, adding an ID-check officer, pooling lanes, and a peak surge baseline.'
)

doc.add_heading('4.2 DES Results', level=2)
table = doc.add_table(rows=1, cols=7)
table.style='Table Grid'
headers=['Configuration','Served','Avg wait','Regular wait','PreCheck wait','p90 wait','Scanner util.']
for i,h in enumerate(headers): table.rows[0].cells[i].text=h
for _,row in des.iterrows():
    cells=table.add_row().cells
    vals=[row['Configuration'], f"{row['served_mean']:.0f}", f"{row['avg_wait_all_mean']:.2f}", f"{row['avg_wait_regular_mean']:.2f}", f"{row['avg_wait_precheck_mean']:.2f}", f"{row['p90_wait_all_mean']:.2f}", f"{row['scan_utilization_mean']:.1f}%"]
    for i,v in enumerate(vals): cells[i].text=str(v)

doc.add_picture(str(base/'airport_des_avg_wait.png'), width=Inches(5.8))
doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
p=doc.add_paragraph('Figure 3. Average wait time by DES configuration.')
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].italic=True

doc.add_picture(str(base/'airport_des_utilization.png'), width=Inches(5.4))
doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
p=doc.add_paragraph('Figure 4. Utilization diagnostic comparing ID-check and scanner stations.')
p.alignment=WD_ALIGN_PARAGRAPH.CENTER
p.runs[0].italic=True

doc.add_paragraph(
    'The DES results show that adding scanner capacity creates the largest wait-time improvement among simple capacity changes, lowering average wait from 0.56 to 0.25 minutes. Adding an ID-check officer barely changes wait time, which indicates the ID station is not the dominant bottleneck. Shared pooled lanes also perform well because flexible capacity reduces imbalance between passenger types.'
)

# ABM

doc.add_heading('5. Agent-Based Model', level=1)
doc.add_paragraph(
    'The ABM captures passenger decision-making rather than only queue mechanics. Passengers are heterogeneous agents with type, patience, urgency, and lane choice. Lanes are agents with type, service rate, queue count, and processed-passenger totals. Each passenger chooses an eligible lane using an effective cost formula: distance to lane + queue count × (1 + urgency). This follows the same logic used in the competing venues activity, where customers evaluate price plus distance penalty.'
)
doc.add_paragraph(
    'The ABM is designed to reveal emergent congestion. Even if total system capacity is adequate, passengers can cluster around one lane, switch lines, or overload regular lanes when PreCheck capacity is underused. These patterns cannot be seen clearly in a static spreadsheet because they arise from individual decisions repeated over time.'
)

doc.add_heading('6. Integration Across the Three Models', level=1)
table = doc.add_table(rows=1, cols=3)
table.style='Table Grid'
for i,text in enumerate(['Model','What It Reveals','How It Connects']): table.rows[0].cells[i].text=text
for row in [
    ['Monte Carlo', 'The airport has meaningful demand-capacity risk: baseline shortfall occurs in 43.4% of simulated peaks.', 'This tells the DES model which scenario needs operational testing.'],
    ['ABM', 'Passenger lane choice can create uneven congestion even when total capacity is not fully used.', 'This explains why pooling or better routing may outperform simply adding staff.'],
    ['DES', 'Scanner capacity and pooled lanes reduce waits more than adding ID-check capacity.', 'This turns risk and behavior insights into a staffing recommendation.'],
]:
    cells=table.add_row().cells
    for i,text in enumerate(row): cells[i].text=text

doc.add_paragraph(
    'The combined story is stronger than any single model. Monte Carlo says the checkpoint faces risk under uncertain demand. ABM says passenger behavior can make that risk worse through clustering and lane switching. DES identifies the specific operational lever: scanner capacity and flexible pooling reduce waits more effectively than adding ID-check officers.'
)

# Validation limitations recommendation

doc.add_heading('7. Validation, Verification, and Limitations', level=1)
doc.add_paragraph(
    'Verification checks: the model behaves sensibly when arrivals are reduced, queues grow under peak surges, and adding capacity at the bottleneck reduces wait. The DES model also reports utilization to verify that capacity changes affect the intended resource. The ABM can be checked by setting PreCheck share to zero, reducing service rates, or forcing all passengers to choose shortest queues.'
)
doc.add_paragraph(
    'Limitations: input parameters are synthetic and should be replaced with airport data if available. The model does not include TSA staffing schedules, passenger group size, mobility constraints, secondary screening, equipment failures, or airline-specific flight-bank timing. The missed-flight risk measure is a proxy rather than actual flight connection data. The ABM lane-choice rule is simplified and assumes passengers can observe queue lengths.'
)

doc.add_heading('8. Recommendation', level=1)
doc.add_paragraph(
    'Recommendation: The airport should prioritize regular scanner capacity and dynamic passenger routing before adding more PreCheck capacity. Under the Monte Carlo model, adding a regular lane reduces expected shortfall from 25.9 to 3.1 passengers and cuts shortfall probability from 43.4% to 7.3%. Under the DES model, adding scanner capacity reduces average wait by more than half. If budget allows, the airport should also consider pooled flexible lanes because pooling performs well by reducing imbalance across passenger types.'
)

doc.add_heading('9. AI Usage Statement', level=1)
doc.add_paragraph(
    'Generative AI tools were used to support coding efficiency, draft prompts, and organize written materials. The simulation design, assumptions, validation checks, interpretation, integration, and recommendations were independently reviewed using the course methodology and project rubric.'
)

doc.add_heading('References', level=1)
refs = [
    'University of Delaware, BUAD 667 Group Project: One System, Three Lenses. Requirement to analyze one system using Monte Carlo simulation, agent-based modeling, and discrete-event simulation.',
    'University of Delaware, BUAD 667 Week 3 Course Materials. Confidence intervals, sensitivity analysis, tornado diagrams, and scenario comparison.',
    'University of Delaware, BUAD 667 Weeks 4-7 Course Materials. Agent-based modeling, agent rules, emergence, BehaviorSpace experimentation, and reward design.',
    'University of Delaware, BUAD 667 Weeks 8-10 Course Materials. Discrete-event simulation, queues, resources, utilization, multiple resources, priority queues, and bottleneck analysis.',
    'University of Delaware, BUAD 667 Week 11 Course Materials. Verification vs. validation, distribution fitting, common random numbers, paired comparisons, and warm-up periods.'
]
for ref in refs:
    doc.add_paragraph(ref, style=None)

# table formatting
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for para in cell.paragraphs:
                for run in para.runs:
                    run.font.size = Pt(8.5)

report_path = base/'Airport_Security_Final_Report.docx'
doc.save(report_path)

# ---------- PPTX ----------
prs = Presentation()
prs.slide_width = PInches(13.333)
prs.slide_height = PInches(7.5)

BLUE = PRGBColor(31,78,121)
GRAY = PRGBColor(90,90,90)
LIGHT = PRGBColor(245,247,250)


def add_title(slide, title, subtitle=None):
    tx = slide.shapes.add_textbox(PInches(0.5), PInches(0.3), PInches(12.3), PInches(0.6))
    p = tx.text_frame.paragraphs[0]
    p.text = title
    p.font.size = PPt(28)
    p.font.bold = True
    p.font.color.rgb = BLUE
    if subtitle:
        st = slide.shapes.add_textbox(PInches(0.55), PInches(0.9), PInches(12), PInches(0.35))
        p2 = st.text_frame.paragraphs[0]
        p2.text = subtitle
        p2.font.size = PPt(13)
        p2.font.color.rgb = GRAY


def add_bullets(slide, bullets, x=0.7, y=1.4, w=5.8, h=5.3, size=18):
    box = slide.shapes.add_textbox(PInches(x), PInches(y), PInches(w), PInches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.clear()
    for i,b in enumerate(bullets):
        p = tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text = b
        p.level = 0
        p.font.size = PPt(size)
        p.space_after = PPt(8)

# Slide 1
s=prs.slides.add_slide(prs.slide_layouts[6])
add_title(s, 'Airport Security & Passenger Flow Optimization', 'One system, three simulation lenses: Monte Carlo, Agent-Based Modeling, and Discrete-Event Simulation')
add_bullets(s, ['BUAD 667 Final Project', 'Business problem: reduce peak checkpoint risk, wait time, and bottlenecks', 'Analysis flow: baseline → sensitivity → scenarios → recommendation'], x=1.0, y=2.0, w=11.0, size=22)

# Slide 2
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Why This System Works')
add_bullets(s, ['Uncertainty: passenger arrivals and service times vary daily', 'Individual behavior: passengers choose lanes based on queue, distance, urgency, and eligibility', 'Process flow: passengers move through ID check → scanner → exit', 'Decision: add scanner, add ID officer, pool lanes, or improve routing?'], x=0.8, y=1.5, w=11.5, size=20)

# Slide 3
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Three Model Questions')
add_bullets(s, ['Monte Carlo: How often does demand exceed planned capacity?', 'ABM: How do passenger lane choices create emergent congestion?', 'DES: Which resource configuration reduces wait and bottlenecks?'], x=0.8, y=1.5, w=11.5, size=22)

# Slide 4
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Monte Carlo Model Design')
add_bullets(s, ['10,000 iterations; seed = 42', 'Arrival rate: Triangular(90, 120, 160) passengers/hour', 'PreCheck share: Triangular(15%, 25%, 35%)', 'Capacity varies by lane type and day', 'Output: shortfall probability, expected shortfall, operational risk cost, CI, tornado diagram'], x=0.7, y=1.35, w=6.0, size=18)
s.shapes.add_picture(str(base/'airport_mc_histogram.png'), PInches(7.0), PInches(1.4), width=PInches(5.8))

# Slide 5
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Monte Carlo Results')
add_bullets(s, [f"Baseline mean demand: {base_mc['Mean passengers']:.0f} passengers / 4-hour peak", f"Probability of any shortfall: {base_mc['P(shortfall)']*100:.1f}%", f"Mean shortfall: {base_mc['Mean shortfall']:.1f} passengers", f"Mean risk cost: ${base_mc['Mean risk cost']:,.0f}", 'Peak surge raises shortfall probability above 80%'], x=0.7, y=1.4, w=5.5, size=19)
s.shapes.add_picture(str(base/'airport_mc_tornado.png'), PInches(6.7), PInches(1.3), width=PInches(6.0))

# Slide 6
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'ABM Model: Passenger Lane Choice')
add_bullets(s, ['Agents: passengers and security lanes', 'Passenger attributes: type, patience, urgency, current lane', 'Lane attributes: lane type, service rate, queue count', 'Decision rule: choose lane with lowest effective cost', 'Emergence: lane clustering and line switching can overload one lane even if total capacity looks sufficient'], x=0.8, y=1.35, w=11.5, size=19)

# Slide 7
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'DES Model Design')
add_bullets(s, ['Entities: arriving passengers', 'Resources: ID-check officers and scanners', 'Queues: FIFO at each station', 'Flow: Arrival → ID check → Scanner → Exit', '30 replications of a 240-minute peak period', 'Metrics: avg wait, p90 wait, max wait, utilization, delay-risk proxy'], x=0.8, y=1.35, w=11.5, size=19)

# Slide 8
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'DES Experiment Results')
s.shapes.add_picture(str(base/'airport_des_avg_wait.png'), PInches(0.7), PInches(1.2), width=PInches(6.0))
s.shapes.add_picture(str(base/'airport_des_utilization.png'), PInches(7.0), PInches(1.2), width=PInches(5.7))

# Slide 9
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'What the DES Shows')
add_bullets(s, ['Baseline average wait: 0.56 minutes', 'Adding scanner capacity lowers average wait to 0.25 minutes', 'Adding an ID-check officer barely changes wait time', 'Shared pooled lanes perform well by reducing imbalance', 'Peak surge roughly doubles average wait'], x=0.8, y=1.5, w=11.5, size=21)

# Slide 10
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Integration: One Story from Three Lenses')
add_bullets(s, ['Monte Carlo: the checkpoint has real demand-capacity risk', 'ABM: passenger choices can create uneven congestion and lane switching', 'DES: scanner capacity and pooling reduce queues more than ID-check expansion', 'Combined insight: do not add capacity blindly—target the bottleneck and improve routing'], x=0.8, y=1.45, w=11.5, size=21)

# Slide 11
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Limitations and Validation')
add_bullets(s, ['Synthetic inputs should be replaced with observed airport data', 'Model excludes equipment failure, secondary screening, group travel, and staffing breaks', 'Validation checks: low arrivals should remove queues; peak surge should grow queues; bottleneck capacity should reduce wait', 'Use distribution fitting and common random numbers if real data becomes available'], x=0.8, y=1.45, w=11.5, size=20)

# Slide 12
s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Recommendation')
add_bullets(s, ['Prioritize regular scanner capacity and dynamic passenger routing', 'Do not add PreCheck capacity first; it does not address the main shortfall', 'Consider pooled flexible lanes to reduce imbalance between passenger types', 'Track p90/max waits and utilization, not only average wait', 'Next step: calibrate inputs with real checkpoint data'], x=0.8, y=1.45, w=11.5, size=21)

ppt_path = base/'Airport_Security_Final_Presentation.pptx'
prs.save(ppt_path)
print(report_path)
print(ppt_path)
