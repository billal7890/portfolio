; Airport Security Lane Choice Agent-Based Model
; Paste this code into NetLogo's Code tab and create the interface widgets listed in README.md.

breed [ passengers passenger ]
breed [ lanes lane ]

passengers-own [
  passenger-type       ; "regular" or "precheck"
  patience             ; maximum queue tolerance
  urgency              ; higher means more sensitive to waiting
  my-lane              ; lane currently chosen
  processed?           ; true after security clearance
]

lanes-own [
  lane-type            ; "regular", "precheck", or "shared"
  service-rate         ; passengers processed per tick
  queue-count
  total-processed
]

to setup
  clear-all
  setup-lanes
  create-passengers num-passengers [
    setxy random-xcor random-ycor
    set shape "person"
    set size 1
    set processed? false
    ifelse random-float 1 < precheck-share [
      set passenger-type "precheck"
      set color blue
    ][
      set passenger-type "regular"
      set color gray
    ]
    set patience 5 + random 15
    set urgency random-float 1
    choose-lane
  ]
  update-queue-counts
  setup-plots
  reset-ticks
end

to setup-lanes
  ; Regular lanes
  create-lanes regular-lanes [
    set lane-type "regular"
    set service-rate regular-service-rate
    set color green
    set shape "square"
    set size 2
    setxy random-xcor max-pycor - 3
    set total-processed 0
  ]
  ; PreCheck lanes
  create-lanes precheck-lanes [
    set lane-type "precheck"
    set service-rate precheck-service-rate
    set color blue
    set shape "square"
    set size 2
    setxy random-xcor min-pycor + 3
    set total-processed 0
  ]
end

to choose-lane
  let eligible-lanes lanes with [ lane-type = [ passenger-type ] of myself or lane-type = "shared" ]
  if any? eligible-lanes [
    ; effective cost combines distance, queue length, and urgency-weighted waiting concern
    set my-lane min-one-of eligible-lanes [ distance myself + queue-count * (1 + [ urgency ] of myself) ]
    face my-lane
  ]
end

to update-queue-counts
  ask lanes [ set queue-count count passengers with [ my-lane = myself and not processed? ] ]
end

to go
  if ticks >= 240 [ stop ]

  ; New arrivals appear gradually during the peak period.
  if random-float 1 < arrival-probability [
    create-passengers 1 [
      setxy random-xcor random-ycor
      set shape "person"
      set size 1
      set processed? false
      ifelse random-float 1 < precheck-share [
        set passenger-type "precheck"
        set color blue
      ][
        set passenger-type "regular"
        set color gray
      ]
      set patience 5 + random 15
      set urgency random-float 1
      choose-lane
    ]
  ]

  update-queue-counts

  ; Passengers reconsider if their lane is much longer than an alternative.
  ask passengers with [ not processed? ] [
    let current-lane my-lane
    choose-lane
    if current-lane != nobody and my-lane != current-lane [
      ; line switching is an emergent behavior driver
      set color yellow
    ]
    if my-lane != nobody [ fd 0.4 ]
  ]

  update-queue-counts
  process-security
  update-queue-counts
  update-plots
  tick
end

to process-security
  ask lanes [
    let capacity floor service-rate
    if random-float 1 < (service-rate - capacity) [ set capacity capacity + 1 ]
    let candidates passengers with [ my-lane = myself and not processed? ]
    if any? candidates [
      ask n-of min list capacity count candidates candidates [
        set processed? true
        set color white
        hide-turtle
      ]
      set total-processed total-processed + min list capacity count candidates
    ]
  ]
end

to setup-plots
  set-current-plot "Queue Lengths"
  clear-plot
  create-temporary-plot-pen "regular"
  set-plot-pen-color green
  create-temporary-plot-pen "precheck"
  set-plot-pen-color blue
end

to update-plots
  set-current-plot "Queue Lengths"
  set-current-plot-pen "regular"
  plot sum [ queue-count ] of lanes with [ lane-type = "regular" ]
  set-current-plot-pen "precheck"
  plot sum [ queue-count ] of lanes with [ lane-type = "precheck" ]
end
