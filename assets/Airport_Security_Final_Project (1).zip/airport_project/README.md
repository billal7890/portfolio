# Airport Security & Passenger Flow Optimization
BUAD 667 Final Project

## Project files
- `airport_mc.py` - Monte Carlo model for checkpoint demand/capacity risk.
- `airport_des.py` - SimPy discrete-event model for passenger flow through ID check and scanner stations.
- `airport_abm_code.nlogo` - NetLogo code-tab model for passenger lane choice and emergent congestion.
- `cursor_prompts_airport_project.txt` - Prompts used/adapted for AI code generation.
- `Airport_Security_Final_Report.docx` - Written report.
- `Airport_Security_Final_Presentation.pptx` - Presentation slides.

## How to run Python models
Install dependencies if needed:

```bash
pip install numpy pandas matplotlib simpy
```

Run Monte Carlo:

```bash
python airport_mc.py
```

Run DES:

```bash
python airport_des.py
```

The scripts save CSV outputs and PNG charts in the working directory.

## How to run the ABM model
Open NetLogo and create these interface widgets:
- Sliders: `num-passengers`, `precheck-share`, `regular-lanes`, `precheck-lanes`, `regular-service-rate`, `precheck-service-rate`, `arrival-probability`
- Buttons: `setup`, `go` forever
- Plot: `Queue Lengths`

Paste `airport_abm_code.nlogo` into the Code tab and run `setup`, then `go`.

Suggested starting values:
- `num-passengers = 250`
- `precheck-share = 0.25`
- `regular-lanes = 3`
- `precheck-lanes = 1`
- `regular-service-rate = 1.0`
- `precheck-service-rate = 1.4`
- `arrival-probability = 0.8`

## Validation checks
- Extreme condition: set arrivals very low; queues should disappear.
- Stress condition: increase arrival probability or reduce service rates; queues should grow.
- Bottleneck sanity: adding capacity at the bottleneck should reduce wait more than adding capacity elsewhere.
- ABM sanity: passengers should prefer shorter/closer lines unless urgency or queue length changes the effective cost.
