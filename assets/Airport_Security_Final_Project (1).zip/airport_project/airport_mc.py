"""
Airport Security Checkpoint Monte Carlo Simulation
BUAD 667 Final Project

Business question: How uncertain is passenger demand during the morning peak,
and how often does the checkpoint's planned capacity become insufficient?

Monte Carlo risk-analysis workflow for airport security operations:
1) baseline simulation and confidence interval
2) one-at-a-time sensitivity analysis
3) scenario comparison
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

np.random.seed(42)
N = 10000
PEAK_HOURS = 4

# Baseline planned capacity assumptions
BASE_REGULAR_LANES = 3
BASE_PRECHECK_LANES = 1
REGULAR_CAPACITY_PER_LANE_PER_HOUR = 32
PRECHECK_CAPACITY_PER_LANE_PER_HOUR = 62

# Cost / penalty assumptions for an operational risk score
STAFF_COST_PER_LANE_HOUR = 85
DELAY_PENALTY_PER_UNSERVED_PASSENGER = 35


def run_mc(arrival_multiplier=1.0, regular_lanes=BASE_REGULAR_LANES, precheck_lanes=BASE_PRECHECK_LANES,
           precheck_share_fixed=None, seed=42):
    rng = np.random.default_rng(seed)
    results = []

    for _ in range(N):
        # Uncertain demand and passenger mix
        total_arrival_rate = rng.triangular(90, 120, 160) * arrival_multiplier  # passengers/hour
        precheck_share = precheck_share_fixed if precheck_share_fixed is not None else rng.triangular(0.15, 0.25, 0.35)
        precheck_share = min(max(precheck_share, 0), 1)

        total_passengers = rng.poisson(total_arrival_rate * PEAK_HOURS)
        precheck_passengers = rng.binomial(total_passengers, precheck_share)
        regular_passengers = total_passengers - precheck_passengers

        # Capacity is also uncertain because service pace varies by day
        regular_capacity_rate = rng.normal(REGULAR_CAPACITY_PER_LANE_PER_HOUR, 5)
        precheck_capacity_rate = rng.normal(PRECHECK_CAPACITY_PER_LANE_PER_HOUR, 6)
        regular_capacity_rate = max(1, regular_capacity_rate)
        precheck_capacity_rate = max(1, precheck_capacity_rate)

        regular_capacity = regular_lanes * regular_capacity_rate * PEAK_HOURS
        precheck_capacity = precheck_lanes * precheck_capacity_rate * PEAK_HOURS

        regular_shortfall = max(0, regular_passengers - regular_capacity)
        precheck_shortfall = max(0, precheck_passengers - precheck_capacity)
        total_shortfall = regular_shortfall + precheck_shortfall

        staffing_cost = (regular_lanes + precheck_lanes) * PEAK_HOURS * STAFF_COST_PER_LANE_HOUR
        risk_cost = staffing_cost + total_shortfall * DELAY_PENALTY_PER_UNSERVED_PASSENGER

        results.append({
            "total_passengers": total_passengers,
            "regular_passengers": regular_passengers,
            "precheck_passengers": precheck_passengers,
            "total_shortfall": total_shortfall,
            "risk_cost": risk_cost,
            "precheck_share": precheck_share,
            "arrival_rate": total_arrival_rate,
        })

    return pd.DataFrame(results)


def summarize(df, label):
    mean_cost = df["risk_cost"].mean()
    std_cost = df["risk_cost"].std(ddof=1)
    ci_low = mean_cost - 1.96 * std_cost / np.sqrt(len(df))
    ci_high = mean_cost + 1.96 * std_cost / np.sqrt(len(df))
    return {
        "Scenario": label,
        "Mean passengers": df["total_passengers"].mean(),
        "Mean shortfall": df["total_shortfall"].mean(),
        "P(shortfall)": (df["total_shortfall"] > 0).mean(),
        "Mean risk cost": mean_cost,
        "Std risk cost": std_cost,
        "5th pct cost": np.percentile(df["risk_cost"], 5),
        "95th pct cost": np.percentile(df["risk_cost"], 95),
        "CI lower": ci_low,
        "CI upper": ci_high,
    }


baseline = run_mc()
baseline_summary = summarize(baseline, "Baseline")

print("AIRPORT SECURITY MONTE CARLO RESULTS")
print("=" * 70)
for k, v in baseline_summary.items():
    if isinstance(v, str):
        print(f"{k}: {v}")
    elif "P(" in k:
        print(f"{k}: {v:.1%}")
    else:
        print(f"{k}: {v:,.2f}")

# Sensitivity analysis: one input at a time using plausible low/high ranges
sensitivity_cases = [
    ("Arrival demand low", {"arrival_multiplier": 0.85}),
    ("Arrival demand high", {"arrival_multiplier": 1.25}),
    ("PreCheck share low", {"precheck_share_fixed": 0.15}),
    ("PreCheck share high", {"precheck_share_fixed": 0.35}),
    ("Add regular lane", {"regular_lanes": 4}),
    ("Add PreCheck lane", {"precheck_lanes": 2}),
]

sens_rows = []
for name, params in sensitivity_cases:
    df = run_mc(**params)
    s = summarize(df, name)
    sens_rows.append(s)

sens = pd.DataFrame(sens_rows)
sens.to_csv("airport_mc_sensitivity.csv", index=False)

print("\nSENSITIVITY RESULTS")
print(sens[["Scenario", "Mean passengers", "Mean shortfall", "P(shortfall)", "Mean risk cost"]].to_string(index=False))

# Scenario comparison
scenarios = {
    "Baseline": baseline,
    "Peak surge (+25% demand)": run_mc(arrival_multiplier=1.25),
    "Add regular lane": run_mc(regular_lanes=4),
    "Add PreCheck lane": run_mc(precheck_lanes=2),
}
scenario_summary = pd.DataFrame([summarize(df, name) for name, df in scenarios.items()])
scenario_summary.to_csv("airport_mc_scenarios.csv", index=False)
print("\nSCENARIO COMPARISON")
print(scenario_summary[["Scenario", "Mean shortfall", "P(shortfall)", "Mean risk cost", "5th pct cost", "95th pct cost"]].to_string(index=False))

# Histogram
plt.figure(figsize=(8, 5))
plt.hist(baseline["risk_cost"], bins=50, alpha=0.8)
plt.axvline(baseline["risk_cost"].mean(), linestyle="--", linewidth=2, label="Mean")
plt.xlabel("Daily peak-period operational risk cost ($)")
plt.ylabel("Frequency")
plt.title("Airport Security Monte Carlo: Baseline Risk Cost")
plt.legend()
plt.tight_layout()
plt.savefig("airport_mc_histogram.png", dpi=200)

# Tornado chart using paired low/high groups, centered on the baseline.
# This version plots deviations from the baseline mean so all bars align on
# a common vertical zero line.
pairs = [
    ("Peak arrival demand", summarize(run_mc(arrival_multiplier=0.85), "low")['Mean risk cost'], summarize(run_mc(arrival_multiplier=1.25), "high")['Mean risk cost']),
    ("PreCheck passenger share", summarize(run_mc(precheck_share_fixed=0.15), "low")['Mean risk cost'], summarize(run_mc(precheck_share_fixed=0.35), "high")['Mean risk cost']),
    ("Regular lane capacity", summarize(run_mc(regular_lanes=4), "high capacity")['Mean risk cost'], summarize(run_mc(regular_lanes=2), "low capacity")['Mean risk cost']),
    ("PreCheck lane capacity", summarize(run_mc(precheck_lanes=2), "high capacity")['Mean risk cost'], summarize(run_mc(precheck_lanes=1), "low capacity")['Mean risk cost']),
]

baseline_cost = baseline_summary["Mean risk cost"]
tornado = pd.DataFrame(pairs, columns=["Input", "Low mean cost", "High mean cost"])
tornado["Low dev"] = tornado["Low mean cost"] - baseline_cost
tornado["High dev"] = tornado["High mean cost"] - baseline_cost
tornado["Min dev"] = tornado[["Low dev", "High dev"]].min(axis=1)
tornado["Max dev"] = tornado[["Low dev", "High dev"]].max(axis=1)
tornado["Spread"] = tornado["Max dev"] - tornado["Min dev"]
tornado = tornado.sort_values("Spread", ascending=False).reset_index(drop=True)
tornado.to_csv("airport_mc_tornado_data.csv", index=False)

fig, ax = plt.subplots(figsize=(9.5, 5.8))
y = np.arange(len(tornado))
for i, row in tornado.iterrows():
    left = row["Min dev"]
    right = row["Max dev"]
    width = right - left
    ax.barh(i, width, left=left, height=0.55)
    low_actual = min(row["Low mean cost"], row["High mean cost"])
    high_actual = max(row["Low mean cost"], row["High mean cost"])
    ax.text(left - 70, i, f"${low_actual:,.0f}", va="center", ha="right", fontsize=8)
    ax.text(right + 70, i, f"${high_actual:,.0f}", va="center", ha="left", fontsize=8)

ax.axvline(0, linestyle="--", linewidth=2, label=f"Baseline = ${baseline_cost:,.0f}")
ax.set_yticks(y)
ax.set_yticklabels(tornado["Input"])
ax.invert_yaxis()
ax.set_xlabel("Change from baseline mean operational risk cost ($)")
ax.set_title("Tornado Diagram: Drivers of Airport Checkpoint Risk")
ax.grid(axis="x", alpha=0.25)
ax.legend(loc="lower right")
max_abs = max(abs(tornado["Min dev"]).max(), abs(tornado["Max dev"]).max())
ax.set_xlim(-max_abs * 1.25, max_abs * 1.25)
fig.tight_layout()
fig.savefig("airport_mc_tornado.png", dpi=220, bbox_inches="tight")
